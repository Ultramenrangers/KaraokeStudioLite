package id.personal.karaokestudiolite

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

data class TimelineClip(
    val imageName: String,
    val startMs: Long,
    val endMs: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KaraokeStudioApp() }
    }
}

@Composable
private fun KaraokeStudioApp() {
    val context = LocalContext.current
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioName by remember { mutableStateOf<String?>(null) }
    var audioDurationMs by remember { mutableLongStateOf(0L) }
    var lyricsUri by remember { mutableStateOf<Uri?>(null) }
    var lyricsName by remember { mutableStateOf<String?>(null) }
    var lyricsText by remember { mutableStateOf("") }
    var imageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var imageNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var timeline by remember { mutableStateOf<List<TimelineClip>>(emptyList()) }
    var status by remember { mutableStateOf("Pilih MP3, lirik, dan gambar untuk mulai.") }

    fun displayName(uri: Uri): String {
        val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) return it.getString(0) ?: uri.lastPathSegment ?: "file"
        }
        return uri.lastPathSegment ?: "file"
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            audioUri = uri
            audioName = displayName(uri)
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                audioDurationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever.release()
                status = if (audioDurationMs > 0) "MP3 siap. Durasi ${formatTime(audioDurationMs)}." else "MP3 dipilih, tetapi durasi belum terbaca."
            } catch (_: Exception) {
                audioDurationMs = 0L
                status = "MP3 dipilih. Durasi belum terbaca; coba file MP3 lain."
            }
            timeline = emptyList()
        }
    }

    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            lyricsUri = uri
            lyricsName = displayName(uri)
            lyricsText = try {
                context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            } catch (_: Exception) { "" }
            status = if (lyricsText.isNotBlank()) "Lirik berhasil dimuat (${lyricsText.lines().count { it.isNotBlank() }} baris)." else "File lirik kosong atau tidak bisa dibaca."
            timeline = emptyList()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            imageUris = uris
            imageNames = uris.map { displayName(it) }
            timeline = emptyList()
            status = "${uris.size} gambar dipilih."
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Karaoke Studio Lite", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("MVP pribadi • target ekspor 720p", style = MaterialTheme.typography.bodyMedium)
                Divider()

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.Icon(Icons.Default.AudioFile, contentDescription = null)
                            Column(Modifier.weight(1f)) {
                                Text("Audio MP3", fontWeight = FontWeight.SemiBold)
                                Text(audioName ?: "Belum dipilih", style = MaterialTheme.typography.bodySmall)
                                if (audioDurationMs > 0) Text("Durasi: ${formatTime(audioDurationMs)}", style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/mpeg", "audio/*")) }) { Text("Pilih") }
                        }
                        Divider()
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.Icon(Icons.Default.TextSnippet, contentDescription = null)
                            Column(Modifier.weight(1f)) {
                                Text("Lirik TXT", fontWeight = FontWeight.SemiBold)
                                Text(lyricsName ?: "Belum dipilih", style = MaterialTheme.typography.bodySmall)
                                if (lyricsText.isNotBlank()) Text("${lyricsText.lines().count { it.isNotBlank() }} baris terbaca", style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { lyricsPicker.launch(arrayOf("text/plain", "text/*")) }) { Text("Pilih") }
                        }
                        Divider()
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.Icon(Icons.Default.Image, contentDescription = null)
                            Column(Modifier.weight(1f)) {
                                Text("Gambar background", fontWeight = FontWeight.SemiBold)
                                Text("${imageUris.size} gambar dipilih", style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }) { Text("Pilih banyak") }
                        }
                    }
                }

                Button(
                    onClick = {
                        if (audioUri == null || lyricsText.isBlank() || imageUris.isEmpty() || audioDurationMs <= 0L) {
                            status = "Lengkapi MP3, lirik TXT, dan minimal satu gambar."
                            timeline = emptyList()
                        } else {
                            val count = imageUris.size
                            val baseDuration = audioDurationMs / count
                            var cursor = 0L
                            timeline = imageNames.mapIndexed { index, name ->
                                val start = cursor
                                val end = if (index == count - 1) audioDurationMs else start + baseDuration
                                cursor = end
                                TimelineClip(name, start, end)
                            }
                            status = "Timeline awal dibuat. Durasi gambar dibagi rata; ini belum menyinkronkan lirik atau merender video."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Susun Timeline Otomatis")
                }

                Text(status, style = MaterialTheme.typography.bodySmall)

                if (timeline.isNotEmpty()) {
                    Text("Preview Timeline (${timeline.size} klip)", fontWeight = FontWeight.Bold)
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = true),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        itemsIndexed(timeline) { index, clip ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.fillMaxWidth().padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("${index + 1}.", fontWeight = FontWeight.Bold)
                                    Column(Modifier.weight(1f)) {
                                        Text(clip.imageName, maxLines = 1)
                                        Text("${formatTime(clip.startMs)} – ${formatTime(clip.endMs)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Tahap ini baru menyiapkan bahan dan timeline gambar. Auto Sync AI, efek visual, preview video, dan ekspor MP4 akan menjadi modul berikutnya.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
